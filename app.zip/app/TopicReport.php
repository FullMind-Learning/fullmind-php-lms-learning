<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TopicReport extends Model
{
    //
}
